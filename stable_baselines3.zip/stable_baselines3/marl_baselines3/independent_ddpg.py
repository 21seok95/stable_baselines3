import copy
from typing import Any, Dict, Optional, Tuple, Type, Union, List
import time
from collections import deque
import torch as th
import gym
import numpy as np
from gym.spaces import Box, Discrete

from stable_baselines3.common.utils import safe_mean, should_collect_more_steps
from stable_baselines3.common.noise import ActionNoise, VectorizedActionNoise
from stable_baselines3.common.utils import (configure_logger, obs_as_tensor,
                                            safe_mean)
from stable_baselines3.common.buffers import ReplayBuffer
from stable_baselines3.common.noise import ActionNoise
from stable_baselines3 import DDPG
from stable_baselines3.common.off_policy_algorithm import OffPolicyAlgorithm
from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, Schedule, RolloutReturn
from stable_baselines3.td3.policies import TD3Policy
from stable_baselines3.td3.td3 import TD3

from stable_baselines3.common.vec_env import VecEnv
from stable_baselines3.common.vec_env import DummyVecEnv


class DummyGymEnv(gym.Env):
    def __init__(self, observation_space, action_space):
        self.observation_space = observation_space
        self.action_space = action_space


class Independent_DDPG(TD3):
    """
    Deep Deterministic Policy Gradient (DDPG).

    Deterministic Policy Gradient: http://proceedings.mlr.press/v32/silver14.pdf
    DDPG Paper: https://arxiv.org/abs/1509.02971
    Introduction to DDPG: https://spinningup.openai.com/en/latest/algorithms/ddpg.html

    Note: we treat DDPG as a special case of its successor TD3.

    :param policy: The policy model to use (MlpPolicy, CnnPolicy, ...)
    :param env: The environment to learn from (if registered in Gym, can be str)
    :param learning_rate: learning rate for adam optimizer,
        the same learning rate will be used for all networks (Q-Values, Actor and Value function)
        it can be a function of the current progress remaining (from 1 to 0)
    :param buffer_size: size of the replay buffer
    :param learning_starts: how many steps of the model to collect transitions for before learning starts
    :param batch_size: Minibatch size for each gradient update
    :param tau: the soft update coefficient ("Polyak update", between 0 and 1)
    :param gamma: the discount factor
    :param train_freq: Update the model every ``train_freq`` steps. Alternatively pass a tuple of frequency and unit
        like ``(5, "step")`` or ``(2, "episode")``.
    :param gradient_steps: How many gradient steps to do after each rollout (see ``train_freq``)
        Set to ``-1`` means to do as many gradient steps as steps done in the environment
        during the rollout.
    :param action_noise: the action noise type (None by default), this can help
        for hard exploration problem. Cf common.noise for the different action noise type.
    :param replay_buffer_class: Replay buffer class to use (for instance ``HerReplayBuffer``).
        If ``None``, it will be automatically selected.
    :param replay_buffer_kwargs: Keyword arguments to pass to the replay buffer on creation.
    :param optimize_memory_usage: Enable a memory efficient variant of the replay buffer
        at a cost of more complexity.
        See https://github.com/DLR-RM/stable-baselines3/issues/37#issuecomment-637501195
    :param create_eval_env: Whether to create a second environment that will be
        used for evaluating the agent periodically. (Only available when passing string for the environment)
    :param policy_kwargs: additional arguments to be passed to the policy on creation
    :param verbose: the verbosity level: 0 no output, 1 info, 2 debug
    :param seed: Seed for the pseudo random generators
    :param device: Device (cpu, cuda, ...) on which the code should be run.
        Setting it to auto, the code will be run on the GPU if possible.
    :param _init_setup_model: Whether or not to build the network at the creation of the instance
    """

    def __init__(
            self,
            policy: Union[str, Type[TD3Policy]],
            num_agents: int,
            env: VecEnv,
            learning_rate: Union[float, Schedule] = 1e-3,
            buffer_size: int = 1_000_000,  # 1e6
            learning_starts: int = 100,
            batch_size: int = 64,
            tau: float = 0.005,
            gamma: float = 0.99,
            train_freq: Union[int, Tuple[int, str]] = (1, "episode"),
            gradient_steps: int = 10,
            action_noise: Optional[ActionNoise] = None,
            replay_buffer_class: Optional[ReplayBuffer] = None,
            replay_buffer_kwargs: Optional[Dict[str, Any]] = None,
            optimize_memory_usage: bool = False,
            tensorboard_log: Optional[str] = None,
            create_eval_env: bool = False,
            policy_kwargs: Optional[Dict[str, Any]] = None,
            verbose: int = 1,
            seed: Optional[int] = None,
            device: Union[th.device, str] = "auto",
            _init_setup_model: bool = True,
    ):

        self.env = env
        self.num_agents = num_agents
        self.num_envs = 1
        self.observation_space = env.observation_space
        self.action_space = env.action_space
        self.tensorboard_log = tensorboard_log
        self.verbose = verbose
        self._logger = None
        env_fn = lambda: DummyGymEnv(self.observation_space, self.action_space)
        dummy_env = DummyVecEnv([env_fn] * self.num_envs)

        self.policies = [
            DDPG(
                policy=policy,
                env=dummy_env,
                learning_rate=learning_rate,
                buffer_size=buffer_size,
                learning_starts=learning_starts,
                batch_size=batch_size,
                tau=tau,
                gamma=gamma,
                train_freq=train_freq,
                gradient_steps=gradient_steps,
                action_noise=action_noise,
                replay_buffer_class=replay_buffer_class,
                replay_buffer_kwargs=replay_buffer_kwargs,
                optimize_memory_usage=optimize_memory_usage,
                policy_kwargs=policy_kwargs,
                verbose=verbose,
                seed=seed,
                device=device,
            )
            for _ in range(self.num_agents)
        ]

    def learn(
            self,
            total_timesteps: int,
            callbacks: Optional[List[MaybeCallback]] = None,
            log_interval: int = 4,
            tb_log_name: str = "IndependentDDPG",
            reset_num_timesteps: bool = True,
    ):
        num_timesteps = 0
        num_rollouts = 0
        all_total_timesteps = []
        if not callbacks:
            callbacks = [None] * self.num_agents
        self._logger = configure_logger(
            self.verbose,
            self.tensorboard_log,
            tb_log_name,
            reset_num_timesteps,
        )
        logdir = self.logger.dir

        # Setup for each policy
        for polid, policy in enumerate(self.policies):
            policy.start_time = time.time()
            if policy.ep_info_buffer is None or reset_num_timesteps:
                policy.ep_info_buffer = deque(maxlen=100)
                policy.ep_success_buffer = deque(maxlen=100)

            if policy.action_noise is not None:
                policy.action_noise.reset()

            if reset_num_timesteps:
                policy.num_timesteps = 0
                policy._episode_num = 0
                all_total_timesteps.append(total_timesteps)
                policy._total_timesteps = total_timesteps
            else:
                # make sure training timestamps are ahead of internal counter
                all_total_timesteps.append(total_timesteps + policy.num_timesteps)
                policy._total_timesteps = total_timesteps + policy.num_timesteps

            policy._logger = configure_logger(
                policy.verbose,
                logdir,
                "policy",
                reset_num_timesteps,
            )

            callbacks[polid] = policy._init_callback(callbacks[polid])

            # -------------------여기까지가 _setup_learn

        for callback in callbacks:
            callback.on_training_start(locals(), globals())

        last_obs = self.env.reset()
        for polid, policy in enumerate(self.policies):
            policy._last_obs = copy.copy(last_obs[polid])


        while num_timesteps < total_timesteps:
            rollout, last_obs, ep_rew, ep_len, dones, last_reward, last_epi_len, itr, infos = self.collect_rollouts(last_obs, callbacks)
            # 기존 ppo와는 collect_rollouts의 매개변수부터가 다르다....

            num_timesteps += self.num_envs * rollout.episode_timesteps
            num_rollouts += 1
            for polid, policy in enumerate(self.policies):
                # and num_timesteps > policy.learning_starts
                if num_timesteps > 0  and num_rollouts%10==0 :
                    fps = int(policy.num_timesteps / (time.time() - policy.start_time))
                    policy.logger.record("policy_id", polid, exclude="tensorboard")
                    if (
                            len(policy.ep_info_buffer) > 0
                            and len(policy.ep_info_buffer[0]) > 0
                    ):
                        policy.logger.record(
                            "rollout/ep_rew_mean",
                            safe_mean(
                                [ep_info["r"] for ep_info in policy.ep_info_buffer]
                            ),
                        )
                        policy.logger.record(
                            "rollout/ep_len_mean",
                            safe_mean(
                                [ep_info["l"] for ep_info in policy.ep_info_buffer]
                            ),
                        )
                    policy.logger.record("time/fps", fps)
                    policy.logger.record(
                        "time/time_elapsed",
                        int(time.time() - policy.start_time),
                        exclude="tensorboard",
                    )
                    policy.logger.record(
                        "time/total_timesteps",
                        policy.num_timesteps,
                        exclude="tensorboard",
                    )
                    policy.logger.dump(step=policy.num_timesteps)
                gradient = copy.copy(policy.gradient_steps)
                if policy.gradient_steps > 0 and num_timesteps>policy.learning_starts:
                    policy.train(batch_size=policy.batch_size, gradient_steps=gradient)
            self.save("0923_1e-3_64_WS_7e-4_IDDPG")
        for callback in callbacks:
            callback.on_training_end()

    def collect_rollouts(self, last_obs, callbacks):
        all_last_episode_starts = [None] * self.num_agents
        all_obs = [None] * self.num_agents
        all_last_obs = [None] * self.num_agents
        all_rewards = [None] * self.num_agents
        all_dones = [None] * self.num_agents
        all_infos = [None] * self.num_agents
        record_reward = [0] * self.num_agents
        record_epi = [0] * self.num_agents
        last_record_reward = [0] * self.num_agents
        last_record_epi = [0] * self.num_agents

        steps = 0
        itr = 0
        # action_noise = [ActionNoise] * self.num_agents

        for polid, policy in enumerate(self.policies):
            for envid in range(self.num_envs):
                assert (
                        last_obs[envid * self.num_agents + polid] is not None
                ), f"No previous observation was provided for env_{envid}_policy_{polid}"
            all_last_obs[polid] = np.array(
                [
                    last_obs[envid * self.num_agents + polid]
                    for envid in range(self.num_envs)
                ]
            )
            policy.policy.set_training_mode(False)
            if policy.action_noise is not None and self.num_envs > 1 and not isinstance(policy.action_noise,
                                                                                            VectorizedActionNoise):
                policy.action_noise = VectorizedActionNoise(policy.action_noise, self.num_envs)
            callbacks[polid].on_rollout_start()

        all_actions = [None] * self.num_agents
        all_buffer_actions = [None] * self.num_agents
        all_values = [None] * self.num_agents
        all_log_probs = [None] * self.num_agents
        all_num_collected_steps = [0] * self.num_agents
        all_num_collected_episodes = [0] * self.num_agents
        num_collected_steps, num_collected_episodes = 0, 0

        while should_collect_more_steps(self.policies[0].train_freq, all_num_collected_steps[0],
                                        all_num_collected_episodes[0]):
            x = should_collect_more_steps(self.policies[0].train_freq, all_num_collected_steps[0],
                                        all_num_collected_episodes[0])
            done_flag = False
            all_actions = [None] * self.num_agents
            all_values = [None] * self.num_agents
            all_log_probs = [None] * self.num_agents

            for polid, policy in enumerate(self.policies):
                all_actions[polid], all_buffer_actions[polid] = policy._sample_action(policy.learning_starts,
                                                                                      policy.action_noise)

            #print(all_actions, all_buffer_actions)
            all_actions = (
                np.vstack(all_actions).transpose().reshape(-1)
            )

            obs, rewards, dones, infos = self.env.step(all_actions)
            #print(rewards)
            for polid in range(self.num_agents):
                all_obs[polid] = np.array(
                    [
                        obs[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )
                all_rewards[polid] = np.array(
                    [
                        rewards[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )
                record_reward[polid] += rewards[polid]
                last_record_reward[polid] += rewards[polid]
                record_epi[polid] += 1
                last_record_epi[polid] += 1

                all_dones[polid] = np.array(
                    [
                        dones[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )
                all_infos[polid] = np.array(
                    [
                        infos[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )

            for polid, policy in enumerate(self.policies):
                policy.num_timesteps += self.num_envs
                all_num_collected_steps[polid] += 1

            for callback in callbacks:
                callback.update_locals(locals())

            if not [callback.on_step() for callback in callbacks]:
                print("##$#$#$#$#$#$#$#$#$#$#$#, independent_ddpg.py, 337")
                return RolloutReturn(0.0, all_num_collected_steps[0] * self.env.num_envs, all_num_collected_episodes[0],
                                     continue_training=False), obs, record_reward, record_epi, dones, last_record_reward, last_record_epi, itr, all_infos

            for polid, policy in enumerate(self.policies):
                policy._update_info_buffer(all_infos[polid], all_dones[polid])
                policy._last_obs = copy.copy(all_last_obs[polid])
                policy._store_transition(policy.replay_buffer, all_buffer_actions[polid], all_obs[polid],  #all_obs와 확인필
                                         all_rewards[polid], all_dones[polid], all_infos[polid])
                policy._update_current_progress_remaining(policy.num_timesteps,
                                                          policy._total_timesteps)  # !!!!!!_total_timesteps 이거 변경필요할
                policy._on_step()

            for polid, policy in enumerate(self.policies):
                done_flag = done_flag or all_dones[polid]
                all_dones[polid] = np.copy(done_flag)

            all_last_obs = np.copy(all_obs)

            if done_flag:
                num_collected_episodes += 1
                all_num_collected_episodes[0] += 1
                policy._episode_num += 1
                last_record_reward = [0] * self.num_agents
                last_record_epi = [0] * self.num_agents
                last_obs = self.env.reset()
                for polid, policy in enumerate(self.policies):
                    # if policy.action_noise is not None:
                    #     kwargs = dict(indices=[polid]) if self.num_envs > 1 else {}
                    #     policy.action_noise.reset(**kwargs)
                    if policy.action_noise is not None:
                        policy.action_noise.reset()
                    all_last_obs[polid] = np.array(
                        [
                            last_obs[envid * self.num_agents + polid]
                            for envid in range(self.num_envs)
                        ]
                    )
        for callback in callbacks:
            callback.on_rollout_end()

        return RolloutReturn(0.0, all_num_collected_steps[0] * self.num_envs, num_collected_episodes,
                             continue_training=True), obs, record_reward, record_epi, dones, last_record_reward, last_record_epi, itr, all_infos


    @classmethod
    def load(
            cls,
            path: str,
            policy: Union[str, Type[TD3Policy]],
            num_agents: int,
            env: VecEnv,
            policy_kwargs: Optional[Dict[str, Any]] = None,
            tensorboard_log: Optional[str] = None,
            verbose: int = 1,
            **kwargs,
    ) -> "Independent_DDPG":
        model = cls(
            policy=policy,
            num_agents=num_agents,
            env=env,
            policy_kwargs=policy_kwargs,
            tensorboard_log=tensorboard_log,
            verbose=verbose,
            **kwargs,
        )
        env_fn = lambda: DummyGymEnv(env.observation_space, env.action_space)
        # DummyVecEnv([env_fn] * self.num_envs)
        dummy_env = DummyVecEnv([env_fn] * 1)
        for polid in range(num_agents):
            model.policies[polid] = DDPG.load(
                path=path + f"/policy_{polid + 1}/model", env=dummy_env, **kwargs
            )
        return model


    def save(self, path: str) -> None:
        for polid in range(self.num_agents):
            self.policies[polid].save(path=path + f"/policy_{polid + 1}/model")
