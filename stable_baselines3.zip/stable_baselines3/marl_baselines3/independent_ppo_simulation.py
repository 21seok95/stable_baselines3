import copy
import time
from collections import deque
from typing import Any, Dict, List, Optional, Type, Union

import gym
import numpy as np
import torch as th
from gym.spaces import Box, Discrete
from stable_baselines3.ppo import PPO
from stable_baselines3.common.on_policy_algorithm import OnPolicyAlgorithm
from stable_baselines3.common.policies import ActorCriticPolicy
from stable_baselines3.common.type_aliases import (GymEnv, MaybeCallback,
                                                   Schedule)
from stable_baselines3.common.utils import (configure_logger, obs_as_tensor,
                                            safe_mean)
from stable_baselines3.common.vec_env import VecEnv
from stable_baselines3.common.vec_env import DummyVecEnv
from matplotlib import pyplot as plt

class DummyGymEnv(gym.Env):
    def __init__(self, observation_space, action_space):
        self.observation_space = observation_space
        self.action_space = action_space


class IndependentPPOSimulation(OnPolicyAlgorithm):
    def __init__(
        self,
        policy: Union[str, Type[ActorCriticPolicy]],
        env: VecEnv,
        num_agents: int = 1,
        learning_rate: Union[float, Schedule] = 3e-4,
        n_steps: int = 2048,
        batch_size: int = 64,
        n_epochs: int = 10,
        gamma: float = 0.99,
        gae_lambda: float = 0.95,
        clip_range: Union[float, Schedule] = 0.2,
        clip_range_vf: Union[None, float, Schedule] = None,
        ent_coef: float = 0.0,
        vf_coef: float = 0.5,
        max_grad_norm: float = 0.5,
        use_sde: bool = False,
        sde_sample_freq: int = -1,
        target_kl: Optional[float] = None,
        tensorboard_log: Optional[str] = None,
        policy_kwargs: Optional[Dict[str, Any]] = None,
        verbose: int = 1,
        device: Union[th.device, str] = "auto",
        num_usr : int = 5,
        act: str = "_ws",
    ):
        self.env = env
        self.act = act
        self.num_usr = num_usr
        self.num_agents = num_agents
        self.num_envs = 1
            #env.num_envs // num_agents
        self.observation_space = env.observation_space
        self.action_space = env.action_space
        self.n_steps = n_steps
        self.tensorboard_log = tensorboard_log
        self.verbose = verbose
        self._logger = None
        env_fn = lambda: DummyGymEnv(self.observation_space, self.action_space)
        dummy_env = DummyVecEnv([env_fn] * self.num_envs)
        self.policies = [
            PPO(
                policy=policy,
                env=dummy_env,
                learning_rate=learning_rate,
                n_steps=n_steps,
                batch_size=batch_size,
                n_epochs=n_epochs,
                gamma=gamma,
                gae_lambda=gae_lambda,
                clip_range=clip_range,
                clip_range_vf=clip_range_vf,
                ent_coef=ent_coef,
                vf_coef=vf_coef,
                max_grad_norm=max_grad_norm,
                target_kl=target_kl,
                use_sde=use_sde,
                sde_sample_freq=sde_sample_freq,
                policy_kwargs=policy_kwargs,
                verbose=verbose,
                device=device,
            )
            for _ in range(self.num_agents)
        ]

    def learn(
        self,
        total_timesteps: int,
        callbacks: Optional[List[MaybeCallback]] = None,
        log_interval: int = 1,
        tb_log_name: str = "IndependentPPO",
        reset_num_timesteps: bool = True,
    ):

        num_timesteps = 0
        all_total_timesteps = []
        if not callbacks:
            callbacks = [None] * self.num_agents
        self._logger = configure_logger(
            self.verbose,
            self.tensorboard_log,
            tb_log_name,
            reset_num_timesteps,
        )
        logdir = self.logger.dir

        # Setup for each policy
        for polid, policy in enumerate(self.policies):
            policy.start_time = time.time()
            if policy.ep_info_buffer is None or reset_num_timesteps:
                policy.ep_info_buffer = deque(maxlen=100)
                policy.ep_success_buffer = deque(maxlen=100)

            if policy.action_noise is not None:
                policy.action_noise.reset()

            if reset_num_timesteps:
                policy.num_timesteps = 0
                policy._episode_num = 0
                all_total_timesteps.append(total_timesteps)
                policy._total_timesteps = total_timesteps
            else:
                # make sure training timestamps are ahead of internal counter
                all_total_timesteps.append(total_timesteps + policy.num_timesteps)
                policy._total_timesteps = total_timesteps + policy.num_timesteps

            policy._logger = configure_logger(
                policy.verbose,
                logdir,
                "policy",
                reset_num_timesteps,
            )

            callbacks[polid] = policy._init_callback(callbacks[polid])

        for callback in callbacks:
            callback.on_training_start(locals(), globals())

        last_obs = self.env.reset()
        for policy in self.policies:
            policy._last_episode_starts = np.ones((self.num_envs,), dtype=bool)

        while num_timesteps < total_timesteps:
            last_obs, ep_rew, ep_len, dones, last_reward, last_epi_len, itr, infos, uav_battery = self.collect_rollouts(last_obs, callbacks)
            if num_timesteps==0:
                uav_old_battery = copy.deepcopy(uav_battery)
                length = len(uav_old_battery[0])
                num_timesteps += 1
            elif len(uav_battery[0]) > (length-10):
                uav_old_battery[0] = copy.copy([(x+y) for x, y in zip(uav_old_battery[0], uav_battery[0])])
                uav_old_battery[1] = copy.copy([(x+y) for x, y in zip(uav_old_battery[1], uav_battery[1])])
                uav_old_battery[2] = copy.copy([(x+y) for x, y in zip(uav_old_battery[2], uav_battery[2])])


                # uav_old_battery[0][0] = copy.copy([(x+y) for x, y in zip(uav_old_battery[0][0], uav_battery[0][0])])
                # uav_old_battery[0][1] = copy.copy([(x+y) for x, y in zip(uav_old_battery[0][1], uav_battery[0][1])])
                #
                # uav_old_battery[1][0] = copy.copy([(x+y) for x, y in zip(uav_old_battery[1][0], uav_battery[1][0])])
                # uav_old_battery[1][2] = copy.copy([(x+y) for x, y in zip(uav_old_battery[1][2], uav_battery[1][2])])
                #
                # uav_old_battery[2][0] = copy.copy([(x+y) for x, y in zip(uav_old_battery[0], uav_battery[0])])
                # uav_old_battery[2][1] = copy.copy([(x+y) for x, y in zip(uav_old_battery[1], uav_battery[1])])
                # uav_old_battery[2][2] = copy.copy([(x+y) for x, y in zip(uav_old_battery[2], uav_battery[2])])

                num_timesteps += 1
                print(num_timesteps)

        my_array_0 = np.array(uav_old_battery[0])
        my_array_0 = my_array_0.transpose()
        my_array_1 = np.array(uav_old_battery[1])
        my_array_1 = my_array_1.transpose()
        my_array_2 = np.array(uav_old_battery[2])
        my_array_2 = my_array_2.transpose()
        # plt.plot(np.array(my_array[0]/(num_timesteps+1)).transpose(), label ='BS')
        # plt.plot(np.array(my_array[1] / (num_timesteps+1)).transpose(), label='UAV')
        #plt.plot(np.array(my_array[1] / num_timesteps).transpose(), label='UAVs')
        np.save('data/queue_info_bs{}_{}'.format(self.num_usr,self.act),np.array(my_array_0[0]/(num_timesteps)))
        np.save('data/queue_info_uav{}_{}'.format(self.num_usr, self.act), np.array(my_array_0[1] / (num_timesteps)))
        np.save('data/complete_task{}_{}'.format(self.num_usr, self.act), np.array(my_array_1[0] / (num_timesteps)))
        np.save('data/offloading{}_{}'.format(self.num_usr, self.act), np.array(my_array_1[2] / (num_timesteps)))
        #np.save('data/uav_battery{}_{}'.format(self.num_usr, self.act), np.array((my_array_2[0]+my_array_2[1]+my_array_2[2])/3)/(num_timesteps))
        np.save('data/uav_battery{}_{}'.format(self.num_usr, self.act),
                np.array((my_array_2[2]))/ (num_timesteps))
        #np.save('data/usr_battery{}_{}'.format(self.num_usr, self.act), np.array(my_array[3][0] / (num_timesteps+1)))
        # plt.title('Number of user : {}'.format(self.num_usr))
        # plt.xlabel('Times')
        # plt.ylabel('waiting_task')
        # plt.legend(loc='best', ncol=3)
        # plt.show()


        for callback in callbacks:
            callback.on_training_end()

    def collect_rollouts(self, last_obs, callbacks):
        all_last_episode_starts = [None] * self.num_agents
        all_obs = [None] * self.num_agents
        all_last_obs = [None] * self.num_agents
        all_rewards = [None] * self.num_agents
        all_dones = [None] * self.num_agents
        all_infos = [None] * self.num_agents
        record_reward = [0] * self.num_agents
        record_epi = [0] * self.num_agents
        last_record_reward = [0] * self.num_agents
        last_record_epi = [0] * self.num_agents

        uav_battery = [[] for i in range(self.num_agents)]


        steps = 0
        itr = 0

        for polid, policy in enumerate(self.policies):
            for envid in range(self.num_envs):
                assert (
                    last_obs[envid * self.num_agents + polid] is not None
                ), f"No previous observation was provided for env_{envid}_policy_{polid}"
            all_last_obs[polid] = np.array(
                [
                    last_obs[envid * self.num_agents + polid]
                    for envid in range(self.num_envs)
                ]
            )
            policy.policy.set_training_mode(False)
            policy.rollout_buffer.reset()
            callbacks[polid].on_rollout_start()

            #이거 왜 쓰는건지 파악해보기####################################3
            all_last_episode_starts[polid] = policy._last_episode_starts

            done_flag = False

        while not done_flag:
            all_actions = [None] * self.num_agents
            all_values = [None] * self.num_agents
            all_log_probs = [None] * self.num_agents
            all_clipped_actions = [None] * self.num_agents



            with th.no_grad():
                for polid, policy in enumerate(self.policies):
                    obs_tensor = obs_as_tensor(all_last_obs[polid], policy.device)
                    (
                        all_actions[polid],
                        all_values[polid],
                        all_log_probs[polid],
                    ) = policy.policy.forward(obs_tensor)
                    clipped_actions = all_actions[polid].cpu().numpy()
                    if isinstance(self.action_space, Box):
                        clipped_actions = np.clip(
                            clipped_actions,
                            self.action_space.low,
                            self.action_space.high,
                        )
                    elif isinstance(self.action_space, Discrete):
                        # get integer from numpy array
                        clipped_actions = np.array(
                            [action.item() for action in clipped_actions]
                        )
                    all_clipped_actions[polid] = clipped_actions

            all_clipped_actions = (
                np.vstack(all_clipped_actions).transpose().reshape(-1)
            )  # reshape as (env, action)
            obs, rewards, dones, infos, user_point = self.env.step(all_clipped_actions)
            # print(all_clipped_actions)
            # print(obs)
            # print()

            for polid in range(self.num_agents):
                all_obs[polid] = np.array(
                    [
                        obs[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )
                all_rewards[polid] = np.array(
                    [
                        rewards[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )
                #record_reward[polid] += rewards[polid]
                uav_battery[polid].append(rewards[polid])
                #last_record_reward[polid] += rewards[polid]
                record_epi[polid] += 1
                last_record_epi[polid] += 1
                all_dones[polid] = np.array(
                    [
                        dones[envid * self.num_agents + polid]
                        for envid in range(self.num_envs)
                    ]
                )

            for policy in self.policies:
                policy.num_timesteps += self.num_envs

            for callback in callbacks:
                callback.update_locals(locals())
            if not [callback.on_step() for callback in callbacks]:
                break

            steps += 1
            # add data to the rollout buffers
            for polid, policy in enumerate(self.policies):
                done_flag = done_flag or all_dones[polid]
                all_dones[polid] = np.copy(done_flag)


            all_last_obs = np.copy(all_obs)
            all_last_episode_starts = np.copy(all_dones)


            if done_flag:
                itr += 1
                last_record_reward = [0] * self.num_agents
                last_record_epi = [0] * self.num_agents
                last_obs = self.env.reset()
                for polid, policy in enumerate(self.policies):
                    all_last_obs[polid] = np.array(
                        [
                            last_obs[envid * self.num_agents + polid]
                            for envid in range(self.num_envs)
                        ]
                    )







        with th.no_grad():
            for polid, policy in enumerate(self.policies):
                obs_tensor = obs_as_tensor(all_last_obs[polid], policy.device)
                _, value, _ = policy.policy.forward(obs_tensor)
                policy.rollout_buffer.compute_returns_and_advantage(
                    last_values=value, dones=all_dones[polid]
                )

        for callback in callbacks:
            callback.on_rollout_end()

        for polid, policy in enumerate(self.policies):
            policy._last_episode_starts = all_last_episode_starts[polid]


        # for i in range(self.num_agents):
        #     record_reward[i] /= itr
        #     record_epi[i] /= itr

        return obs, record_reward, record_epi, dones, last_record_reward, last_record_epi, itr, all_infos, uav_battery

    @classmethod
    def load(
        cls,
        path: str,
        policy: Union[str, Type[ActorCriticPolicy]],
        num_agents: int,
        env: VecEnv,
        n_steps: int,
        policy_kwargs: Optional[Dict[str, Any]] = None,
        tensorboard_log: Optional[str] = None,
        verbose: int = 1,
        **kwargs,
    ) -> "IndependentPPO":
        model = cls(
            policy=policy,
            num_agents=num_agents,
            env=env,
            n_steps=n_steps,
            policy_kwargs=policy_kwargs,
            tensorboard_log=tensorboard_log,
            verbose=verbose,
            **kwargs,
        )
        env_fn = lambda: DummyGymEnv(env.observation_space, env.action_space)
        #DummyVecEnv([env_fn] * self.num_envs)
        dummy_env = DummyVecEnv([env_fn] * 1)
        for polid in range(num_agents):
            model.policies[polid] = PPO.load(
                path=path + f"/policy_{polid + 1}/model", env=dummy_env, **kwargs
            )
        return model

    def save(self, path: str) -> None:
        for polid in range(self.num_agents):
            self.policies[polid].save(path=path + f"/policy_{polid + 1}/model")

